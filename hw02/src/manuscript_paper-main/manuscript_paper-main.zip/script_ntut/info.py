TOTAL_PAGES = 1
# personal information below
ID = " "  # student ID here
NAME = " "  # name here
NUMBER = 1  # number here
